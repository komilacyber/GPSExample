# GPSExample in class
